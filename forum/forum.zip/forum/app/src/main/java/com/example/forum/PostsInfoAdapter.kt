package com.example.forum

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.posts_item.view.*

class PostsInfoAdapter(): RecyclerView.Adapter<PostsInfoAdapter.ViewHolder>() {

    lateinit var items : MutableList<PostsInfo>
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context).inflate(R.layout.posts_item,parent,false) as View
        return ViewHolder(inflater)
    }
    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item : PostsInfo = items.get(position)
        holder.setItem(item)
    }
    public fun addItem(item: PostsInfo) {
        items.add(item)
    }
    public fun setItemLists(items : MutableList<PostsInfo> ){
        this.items = items
    }
    public fun getItem(position: Int): PostsInfo{
        return items.get(position)
    }
    public fun setItem(position: Int,item: PostsInfo): PostsInfo{
        return items.set(position,item)
    }

     inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        public fun setItem(item: PostsInfo){
            itemView.postsTitle.setText(item.postsTitle)
            itemView.postsView.setText(item.postsView!!)
            itemView.authorsName.setText(item.authorsName)
            itemView.recommendCount.setText(item.recommendCount!!)
            itemView.writtenDate.setText(item.writtenDate)




        }
    }




}