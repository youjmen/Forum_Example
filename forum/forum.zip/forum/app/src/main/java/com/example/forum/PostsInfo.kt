package com.example.forum

class PostsInfo(postsTitle: String, postsView : Int?, authorsName : String, recommendCount: Int?, writtenDate : String ) {
    lateinit var postsTitle : String
    var postsView : Int? = null
    lateinit var authorsName : String
    var recommendCount : Int? = null
    lateinit var writtenDate : String


}